const TractorName = document.getElementById("name")
const make = document.getElementById("make")
const model = document.getElementById("model")
const vin = document.getElementById("vin")
const year = document.getElementById("year")


function addTractor() { 

let Tractor = {
    "id": "",
    "dot": "",
    "vin": vin.value,
    "name": TractorName.value,
    "make": make.value,
    "model": model.value,
    "year": year.value,
    "status": "",
    "organizationId": ""
  }

   fetch("http://10.20.8.158:5002/api/v2/tractors/create", {
        method: "POST" ,
        headers: {
            "Content-type" : "application/json"
        },
        body: JSON.stringify(

            Tractor
        )
    }).then(res => {
        if (res.ok) { console.log("HTTP request successful") }
        else { console.log("HTTP request unsuccessful") }
        return res
    })
    .then(res => res.json())
    .then(data => console.log(data))
    .catch(error => console.log(error))
    
}
