let email = document.getElementById("email")
let pass = document.getElementById("password")
let dot = document.getElementById("dot")
let userName = document.getElementById("email")
let org = document.getElementById("org")
let form = document.getElementById("sub_log")
let dot_log = document.getElementById("dot_log")
let mail_log = document.getElementById("mail_log")
let pass_log = document.getElementById("pass_log")


const myData = {};

function register(){ 

    let data = {
    "email" : email.value, 
    "password" : pass.value , 
    "dot" : dot.value , 
    "name" : userName.value , 
    "organizationName" : org.value
    }


    fetch("http://10.20.8.158:5002/api/v2/accounts/register/", {
        method: "PUT" ,
        headers: {
            "Content-type" : "application/json"
        },
        body: JSON.stringify(

            data
        )
    }).then(res => {
        if (res.ok) { console.log("HTTP request successful") }
        else { console.log("HTTP request unsuccessful") }
        return res
    })
    .then(res => res.json())
    .then(data => console.log(data))
    .catch(error => console.log(error))
    

    myData.push(data)
    

}




// function Login(){
//     let data = {
//         "email" : email.value, 
//         "password" : pass.value , 
//         "dot" : dot.value ,
//         }
    



//     if(pass_log.value == myData.pass && mail_log.value == myData.email && dot_log.value == myData.dot)
//     {
//         fetch("http://10.20.8.158:5002/api/v2/accounts/login/", {
//             method: "POST" ,
//             headers: {
//                 "Content-type" : "application/json"
//             },
//             body: JSON.stringify(
    
//                 data
//             )
//         }).then(res => res.json()).then(data => console.log(data) || myObj.push(data))



//         location.href = "index.html";
//     }

//     }
    


// form.addEventListener("submit",(e) => {
//     console.log("form")
//     e.preventDefault();
    
    
//     if(pass_log.value == data.pass && mail_log.value == data.email && dot_log.value == data.dot){
//         // fetch("http://10.20.8.158:5002/api/v2/accounts/login/", {
//             //     method: "POST" ,
//             //     headers: {
//                 //         "Content-type" : "application/json"
//                 //     },
//                 //     body: JSON.stringify(
                    
//                     //         data
//                     //     )
//                     // }).then(res => res.json()).then(data => console.log(data) || myObj.push(data))
                    
                    
                    
//                     location.href = "index.html";
//                 }
                
//             } )
            
//             console.log(form)
// console.log(myObj)