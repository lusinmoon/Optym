const driverName = document.getElementById("name")
const email = document.getElementById("email")
const phone = document.getElementById("phone")
const pass = document.getElementById("pass")

console.log(email.value)
function addDriver() { 

let Driver = {
    "email": email.value,
    "password": pass.value,
    "name":driverName.value,
    "dot": "",
    "phone": phone.value,
    "organizationId": ""
  }

   fetch("http://10.20.8.158:5002/api/v2/accounts/add/driver/", {
        method: "POST" ,
        headers: {
            "Content-type" : "application/json"
        },
        body: JSON.stringify(

            Driver
        )
    }).then(res => {
        if (res.ok) { console.log("HTTP request successful") }
        else { console.log("HTTP request unsuccessful") }
        return res
    })
    .then(res => res.json())
    .then(data => console.log(data))
    .catch(error => console.log(error))
    
}
