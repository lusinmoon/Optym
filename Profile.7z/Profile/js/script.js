const container = document.getElementsByClassName(".container")
const acc = document.getElementById("acc")
const mail = document.getElementById("mail")
const  orgnazValue = document.getElementById("org")
const submit = document.getElementsByClassName("button")
const phone= document.getElementById("phone")
const zoom = document.getElementById("zoom")

let myData = {
    id : "630cb930ceca992813d15bc5",
   dot  : "281299",
    name: "moon@gmail.com",
    organizationId: "630cb930ceca992813d15bc4",
    organizationName: "Moon11",
    email: "moon@gmail.com",
    timezone: "America/New_York",
    accountType: "ADMIN",
    lastLoginDate: "2022-08-30T06:14:17.615+00:00"
  }

orgnazValue.innerText = myData.organizationName
acc.innerText = myData.accountType
mail.innerText = myData.email




function Update (){
          let UpData = {
                  "id": myData.id,
                  "dot": myData.dot,
                  "name": myData.name,
                  "organizationId": myData.organizationId,
                  "organizationName": myData.organizationName,
                  "email": myData.email,
                  "phone": phone.value,
                  "zoom": zoom.value,
                  "timezone": myData.timezone,
                  "accountType": myData.accountType,
                  "lastLoginDate": myData.lastLoginDate,
                  "status": ""
          }
        console.log(UpData)
   
    fetch("http://10.20.8.158:5002/api/v2/accounts/user/update/", {
        method: "PUT" ,
        headers: {
            "Content-type" : "application/json"
        },
        body: JSON.stringify(

            UpData
        )
    }).then(res => {
        if (res.ok) { console.log("HTTP request successful") }
        else { console.log("HTTP request unsuccessful") }
        return res
    })
    .then(res => res.json())
    .then(data => console.log(data))
    .catch(error => console.log(error))
    

}