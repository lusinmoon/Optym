"use strict";

const data = document.forms[0];


data.addEventListener("submit", (e) => {
  e.preventDefault();
  if (
    data.elements[1].value == "login" &&
    data.elements[2].value == "pass"
  ) {
    localStorage.setItem("loggedIn", "true");
    location.href = "index.html";
  } else {
    alert("error");
  }
});



//fatch("​/api​/v2​/accounts​/login/").then((response) => console.log(response));
