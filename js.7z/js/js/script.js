// let email = document.getElementById("email")
// let pass = document.getElementById("pass")
// let dot = document.getElementById("dot")
// let userName = document.getElementById("email")
// let org = document.getElementById("org")
// let form = document.getElementById("sub")



// function store()
// { 

//     localStorage.setItem('email', email.value)
//     localStorage.setItem('password', pass.value)
//     localStorage.setItem('dot', dot.value)

// }
// ;




window.addEventListener("DOMContentLoaded", (e) => {
    
      if (localStorage.getItem("loggedIn"))
        header.insertAdjacentElement("afterend", addForm);
     });
    

// let email = document.getElementById("email");
// let password = document.getElementById("password");
// let dot = document.getElementById("dot");
// let username = document.getElementById("name");
// let id = document.getElementById("org");


// console.log(email.value)
// let userOrg = org.value
// let userEmail = email.value
// //const userPass = password.value
// let userName = username.value
// let useDdot = dot.value

// let data = [userOrg,userEmail,userName,useDdot]
// console.log(data)

// function store()
// { 

//     localStorage.setItem('email',data.userEmail)
//     localStorage.setItem('password', password.value)
//     localStorage.setItem('dot',dot.value)

// }



//  function User() {

//     const arr = new Array
//     usrs = new Object
 

  
// }

//      arr.push(usrs)
//      console.log(arr)
//  }

//  User()


// function checkLogin()
// {
//     let emailStored = localStorage.getItem('email')
//     let passwordStored = localStorage.getItem('password')


//     let emailInput = document.querySelectorById('email').value
//     let passwordInput = document.querySelectorById('password').value

//     if(emailInput != emailStored)
//     {
//        let eError = document.querySelector(".email-error-message")
//        eError.innerHTML = "Please enter valid email address"
//     }

//     if(passwordInput != passwordStored)
//     {
//         let pError = document.querySelector(".password-error-message")
//         pError.innerHTML = "Please enter password associated with email address"
//     }

// }


//  function Login() {

//     const  Array = new Array
//     user = new Object
 

// user = {
//     organizationName: "",
//     email: "",
//     password: "",
//     name: "",
//     dot: ""
  
// }

// Array.push(user)
//  }

// const username = document.getElementById("email").value;
// console.log(username)
// const password = document.getElementById("pass").value;
// const dot = document.getElementById("dot").value;


// sessionStorage.setItem("currentloggedin",username);

// localStorage.setItem('all_users',JSON.stringify(a));

// Array=JSON.parse((localStorage.getItem("all_users")));
// Array.push({name: username, password: password});
// localStorage.setItem('name',JSON.stringify(a));
// for(var i=0; i<a.length; i++)
//   {
//    var li = document.createElement("li");
//    li.innerHTML=a[i]['name'];
//    document.getElementById("listuser").appendChild(li);
//   }


// const Http = new XMLHttpRequest();
// const url='http://10.20.8.158:5002/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/account-resource/register';
// Http.open("GET", url);
// Http.send();

// Http.onreadystatechange = (e) => {
//   console.log(Http.responseText)
// }

  
