let email = document.getElementById("email")
let pass = document.getElementById("password")
let dot = document.getElementById("dot")
let userName = document.getElementById("email")
let org = document.getElementById("org")
let form = document.getElementById("sub_log")
let dot_log = document.getElementById("dot_log")
let mail_log = document.getElementById("mail_log")
let pass_log = document.getElementById("pass_log")




const myObj = {}

function Login(){
    console.log("boo")}

form.addEventListener("submit",(e) => {
    e.preventDefault();
    if(pass_log == data.pass && mail_log == data.email && dot_log == data.dot){
        fetch("http://10.20.8.158:5002/api/v2/accounts/login/", {
            method: "POST" ,
            headers: {
                "Content-type" : "application/json"
            },
            body: JSON.stringify(
    
                data
            )
        }).then(res => res.json()).then(data => console.log(data) || myObj.push(data))



        location.href = "index.html";
    }

 } )

console.log(myObj)